// let str = 'aaa@bbb@ccc';
// str = str.replaceAll('@', '!')
// console.log(str);


// let str = 'HELLOWORLD'
// let h = str[0] + str.slice(1, 5).toLowerCase() + str[5].toLowerCase() + str.slice(6).toLowerCase();
// console.log(h);

// let str = 'Hello, it is HTML'
// let h = str.slice(0, 6) + str.slice(6, 14) + 'not JS';
// console.log(h);

// let  a = 'alex';
// let b = a.slice(0, 1).toUpperCase() + a.slice(1, 4);
// console.log(b);

// let a = Math.random();
// a = Math.random().toString().replace('.', '');
// console.log(a);

// const a = 'Lex Luter has a big suit';
// const b = a.slice(a.indexOf('a'), a.indexOf('a') + 1).toUpperCase();
// const c = a.slice(a.indexOf('Lex'), a.indexOf('Lex') + 3);
// console.log(b + c);

