
const companies = [
  { name: "Apple", income: [10000, 12000, 500], spend: 23000 },
  { name: "Microsoft", income: [10000, 12000, 1500], spend: 17000 },
  { name: "Google", income: [15000, 20000, 4000], spend: 7000 },
  { name: "SpaceX", income: [150000, 62000, 2000], spend: 99000 },
  { name: "GM motors", income: [15000, 20000, 4000], spend: 100 },
];

let = totalIncome = 0


for (let i = 0; i < companies.length; i++) {
  let incomeSum = 0;
  companies[i].total = ' ';

  for (let j = 0; j < companies[i].income.length; j++) {
    incomeSum += companies[i].income[j];
  }

  totalIncome += incomeSum - companies[i].spend
}


console.log(companies);
console.log(totalIncome);